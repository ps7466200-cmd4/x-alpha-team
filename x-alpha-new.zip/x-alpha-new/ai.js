// X-ALPHA Health AI Assistant
class XAlphaAI {
    constructor() {
        this.apiKey = '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';
        this.model = 'openai/gpt-4o-mini'; // GPT-4o-mini model from OpenRouter[citation:2]
        this.endpoint = 'https://openrouter.ai/api/v1/chat/completions';
        this.conversation = [];
        this.isProcessing = false;
        
        // Initialize when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            if (document.getElementById('ai-assistant-section')) {
                this.initializeAI();
            }
        });
    }
    
    initializeAI() {
        // Create AI interface
        const aiContainer = document.getElementById('aiContainer');
        if (!aiContainer) return;
        
        aiContainer.innerHTML = `
            <div class="ai-chat-container">
                <div class="ai-header">
                    <div class="ai-avatar">
                        <i class="fas fa-robot"></i>
                        <div class="avatar-pulse"></div>
                    </div>
                    <div class="ai-info">
                        <h3>X-ALPHA Health AI</h3>
                        <p>Your futuristic health assistant powered by GPT-4o-mini[citation:2]</p>
                        <div class="ai-status">
                            <span class="status-dot active"></span>
                            <span>SYSTEM ONLINE</span>
                        </div>
                    </div>
                </div>
                
                <div class="ai-chat-messages" id="aiChatMessages">
                    <!-- Messages will appear here -->
                </div>
                
                <div class="ai-chat-input">
                    <div class="input-wrapper">
                        <input type="text" id="aiMessageInput" placeholder="Ask me anything about health, wellness, or medical advice...">
                        <button id="sendAiMessage">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                    <div class="quick-prompts">
                        <button class="quick-prompt" data-prompt="What are the symptoms of COVID-19?">
                            <i class="fas fa-virus"></i> COVID-19 Symptoms
                        </button>
                        <button class="quick-prompt" data-prompt="How can I improve my sleep quality?">
                            <i class="fas fa-bed"></i> Sleep Tips
                        </button>
                        <button class="quick-prompt" data-prompt="What foods are good for heart health?">
                            <i class="fas fa-heart"></i> Heart Health
                        </button>
                        <button class="quick-prompt" data-prompt="How much water should I drink daily?">
                            <i class="fas fa-tint"></i> Hydration
                        </button>
                    </div>
                    <p class="ai-disclaimer">
                        <i class="fas fa-exclamation-triangle"></i>
                        This AI provides general health information only. Always consult a healthcare professional for medical advice.
                    </p>
                </div>
            </div>
        `;
        
        // Add initial welcome message
        this.addMessage('ai', 'Hello! I\'m X-ALPHA Health AI, your futuristic health assistant. I can provide information on various health topics, wellness tips, and general medical guidance. How can I help you today?');
        
        // Add event listeners
        this.attachEventListeners();
        
        // Update user stats
        this.updateUserStats();
    }
    
    attachEventListeners() {
        const input = document.getElementById('aiMessageInput');
        const sendBtn = document.getElementById('sendAiMessage');
        const quickPrompts = document.querySelectorAll('.quick-prompt');
        
        // Send message on button click
        sendBtn.addEventListener('click', () => this.sendMessage());
        
        // Send message on Enter key
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Quick prompts
        quickPrompts.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prompt = e.currentTarget.getAttribute('data-prompt');
                input.value = prompt;
                this.sendMessage();
            });
        });
    }
    
    async sendMessage() {
        const input = document.getElementById('aiMessageInput');
        const message = input.value.trim();
        
        if (!message || this.isProcessing) return;
        
        // Add user message to chat
        this.addMessage('user', message);
        input.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Update conversation history
        this.conversation.push({
            role: 'user',
            content: message
        });
        
        // Update user stats
        this.updateUserStats();
        
        try {
            this.isProcessing = true;
            
            // Call OpenRouter API
            const response = await this.callOpenRouterAPI();
            
            // Remove typing indicator
            this.removeTypingIndicator();
            
            // Add AI response to chat
            if (response && response.choices && response.choices[0]) {
                const aiResponse = response.choices[0].message.content;
                this.addMessage('ai', aiResponse);
                
                // Update conversation history
                this.conversation.push({
                    role: 'assistant',
                    content: aiResponse
                });
            } else {
                throw new Error('Invalid API response');
            }
            
        } catch (error) {
            console.error('AI Error:', error);
            this.removeTypingIndicator();
            this.addMessage('ai', 'I apologize, but I\'m having trouble connecting to the AI service. Please try again in a moment. If the problem persists, check your internet connection.');
        } finally {
            this.isProcessing = false;
        }
    }
    
    async callOpenRouterAPI() {
        const response = await fetch(this.endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.apiKey}`,
                'HTTP-Referer': window.location.origin,
                'X-Title': 'X-ALPHA Dashboard'
            },
            body: JSON.stringify({
                model: this.model,
                messages: [
                    {
                        role: 'system',
                        content: 'You are X-ALPHA Health AI, a futuristic health assistant. Provide helpful, accurate, and concise information about health, wellness, and medical topics. Always include disclaimers about consulting healthcare professionals. Format responses with clear paragraphs and use bullet points when appropriate. Keep responses under 300 words.'
                    },
                    ...this.conversation.slice(-6) // Keep last 6 messages for context
                ],
                max_tokens: 500,
                temperature: 0.7
            })
        });
        
        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }
        
        return await response.json();
    }
    
    addMessage(sender, text) {
        const messagesContainer = document.getElementById('aiChatMessages');
        if (!messagesContainer) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = `message ${sender}-message`;
        
        const timestamp = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        messageElement.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
            </div>
            <div class="message-content">
                <div class="message-text">${this.formatMessage(text)}</div>
                <div class="message-time">${timestamp}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Add animation
        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            messageElement.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
        }, 10);
    }
    
    formatMessage(text) {
        // Simple formatting for URLs and line breaks
        let formatted = text
            .replace(/\n/g, '<br>')
            .replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
        
        // Add some styling for important points
        formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        return formatted;
    }
    
    showTypingIndicator() {
        const messagesContainer = document.getElementById('aiChatMessages');
        if (!messagesContainer) return;
        
        const typingElement = document.createElement('div');
        typingElement.className = 'message ai-message typing-indicator';
        typingElement.id = 'typingIndicator';
        
        typingElement.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="message-time">Just now</div>
            </div>
        `;
        
        messagesContainer.appendChild(typingElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    removeTypingIndicator() {
        const typingElement = document.getElementById('typingIndicator');
        if (typingElement) {
            typingElement.remove();
        }
    }
    
    updateUserStats() {
        // Update AI chat count in user stats
        const user = getUserData();
        if (user) {
            user.aiChatCount = (user.aiChatCount || 0) + 1;
            localStorage.setItem('xalpha_user', JSON.stringify(user));
            
            // Update UI if on profile page
            const aiChatCountElement = document.getElementById('aiChatCount');
            if (aiChatCountElement) {
                aiChatCountElement.textContent = user.aiChatCount;
            }
        }
    }
}

// Initialize AI when script loads
const xalphaAI = new XAlphaAI();

// Helper function to get user data (from script.js)
function getUserData() {
    const userData = localStorage.getItem('xalpha_user');
    return userData ? JSON.parse(userData) : null;
}

// Export for use in dashboard
function initializeAIChat() {
    // Already initialized via constructor
}

// Add AI-specific CSS
document.addEventListener('DOMContentLoaded', function() {
    const aiStyles = `
        .ai-chat-container {
            display: flex;
            flex-direction: column;
            height: 600px;
            background: rgba(16, 18, 36, 0.7);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(0, 243, 255, 0.3);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }
        
        .ai-header {
            padding: 25px;
            background: rgba(0, 0, 0, 0.3);
            border-bottom: 1px solid rgba(0, 243, 255, 0.2);
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .ai-avatar {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 32px;
            color: var(--dark-bg);
            position: relative;
        }
        
        .avatar-pulse {
            position: absolute;
            top: -5px;
            left: -5px;
            right: -5px;
            bottom: -5px;
            border-radius: 50%;
            background: inherit;
            opacity: 0.5;
            animation: pulse 2s infinite;
            z-index: -1;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.05); opacity: 0.3; }
        }
        
        .ai-info h3 {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            margin-bottom: 5px;
            color: var(--primary-color);
        }
        
        .ai-info p {
            color: var(--text-secondary);
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .ai-status {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #666;
        }
        
        .status-dot.active {
            background: var(--success-color);
            box-shadow: 0 0 10px var(--success-color);
            animation: pulseStatus 2s infinite;
        }
        
        .ai-chat-messages {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .message {
            display: flex;
            gap: 15px;
            max-width: 85%;
            animation: fadeIn 0.3s ease;
        }
        
        .user-message {
            align-self: flex-end;
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        
        .user-message .message-avatar {
            background: linear-gradient(135deg, var(--accent-color), #cc00cc);
            color: white;
        }
        
        .ai-message .message-avatar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--dark-bg);
        }
        
        .message-content {
            flex: 1;
        }
        
        .user-message .message-content {
            align-items: flex-end;
            text-align: right;
        }
        
        .message-text {
            padding: 15px;
            border-radius: 15px;
            font-size: 15px;
            line-height: 1.5;
        }
        
        .user-message .message-text {
            background: linear-gradient(135deg, var(--accent-color), #cc00cc);
            color: white;
            border-bottom-right-radius: 5px;
        }
        
        .ai-message .message-text {
            background: rgba(0, 243, 255, 0.1);
            border: 1px solid rgba(0, 243, 255, 0.2);
            color: var(--text-color);
            border-bottom-left-radius: 5px;
        }
        
        .message-time {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        
        .typing-indicator .message-text {
            background: none;
            border: none;
            padding: 0;
        }
        
        .typing-dots {
            display: flex;
            gap: 5px;
            padding: 15px;
            background: rgba(0, 243, 255, 0.1);
            border: 1px solid rgba(0, 243, 255, 0.2);
            border-radius: 15px;
            width: fit-content;
            border-bottom-left-radius: 5px;
        }
        
        .typing-dots span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--primary-color);
            animation: typing 1.4s infinite ease-in-out;
        }
        
        .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
        .typing-dots span:nth-child(2) { animation-delay: -0.16s; }
        
        @keyframes typing {
            0%, 80%, 100% { transform: scale(0.6); opacity: 0.6; }
            40% { transform: scale(1); opacity: 1; }
        }
        
        .ai-chat-input {
            padding: 25px;
            border-top: 1px solid rgba(0, 243, 255, 0.2);
            background: rgba(0, 0, 0, 0.3);
        }
        
        .input-wrapper {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        #aiMessageInput {
            flex: 1;
            padding: 15px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(0, 243, 255, 0.3);
            border-radius: 10px;
            color: var(--text-color);
            font-family: 'Exo 2', sans-serif;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        #aiMessageInput:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.3);
        }
        
        #sendAiMessage {
            width: 60px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 10px;
            color: var(--dark-bg);
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        #sendAiMessage:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 243, 255, 0.3);
        }
        
        .quick-prompts {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .quick-prompt {
            padding: 10px 15px;
            background: rgba(0, 243, 255, 0.1);
            border: 1px solid rgba(0, 243, 255, 0.3);
            border-radius: 8px;
            color: var(--primary-color);
            font-family: 'Exo 2', sans-serif;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .quick-prompt:hover {
            background: rgba(0, 243, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(0, 243, 255, 0.2);
        }
        
        .ai-disclaimer {
            font-size: 12px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            background: rgba(255, 51, 102, 0.1);
            border-radius: 8px;
            border: 1px solid rgba(255, 51, 102, 0.3);
        }
        
        .ai-disclaimer i {
            color: var(--danger-color);
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = aiStyles;
    document.head.appendChild(styleSheet);
});