// ===== GLOBAL VARIABLES =====
const API_KEYS = {
    openRouter: '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',
    weather: '8f376d0650b74e158fc175823251012',
    nasa: 'xqGp6BGkrUEs5HbJ14pgUBHW6ZMOKiGAlb6C7gAn'
};

// ===== LOGIN PAGE FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the login page
    if (document.querySelector('#loginForm')) {
        const loginForm = document.getElementById('loginForm');
        const loadingOverlay = document.getElementById('loadingOverlay');
        
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            // Basic validation
            if (!username || !password) {
                showNotification('Please enter both username and password', 'error');
                return;
            }
            
            // Get stored user data
            const storedUser = localStorage.getItem('xalpha_user');
            
            if (storedUser) {
                const user = JSON.parse(storedUser);
                
                // Check credentials
                if (user.username === username && user.password === password) {
                    // Update login stats
                    user.loginCount = (user.loginCount || 0) + 1;
                    user.lastLogin = new Date().toISOString();
                    localStorage.setItem('xalpha_user', JSON.stringify(user));
                    
                    // Show loading animation
                    showLoading();
                    
                    // Simulate loading delay, then redirect
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 2000);
                } else {
                    showNotification('Invalid username or password', 'error');
                }
            } else {
                showNotification('No user found. Please register first.', 'error');
            }
        });
    }
    
    // ===== REGISTRATION PAGE FUNCTIONALITY =====
    if (document.querySelector('#registerForm')) {
        const registerForm = document.getElementById('registerForm');
        
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('regUsername').value.trim();
            const password = document.getElementById('regPassword').value.trim();
            const confirmPassword = document.getElementById('confirmPassword').value.trim();
            
            // Validation
            if (username.length < 4) {
                showNotification('Username must be at least 4 characters', 'error');
                return;
            }
            
            if (password.length < 6) {
                showNotification('Password must be at least 6 characters', 'error');
                return;
            }
            
            if (password !== confirmPassword) {
                showNotification('Passwords do not match', 'error');
                return;
            }
            
            // Check if user already exists
            const existingUser = localStorage.getItem('xalpha_user');
            if (existingUser) {
                const userData = JSON.parse(existingUser);
                if (userData.username === username) {
                    showNotification('Username already exists. Please choose another.', 'error');
                    return;
                }
            }
            
            // Create user object
            const user = {
                username: username,
                password: password, // In a real app, this should be hashed
                createdAt: new Date().toISOString(),
                loginCount: 0,
                aiChatCount: 0,
                weatherChecks: 0,
                theme: 'cyberpunk'
            };
            
            // Save to localStorage
            localStorage.setItem('xalpha_user', JSON.stringify(user));
            
            // Show success message
            showNotification('Account created successfully! Redirecting to login...', 'success');
            
            // Redirect to login after delay
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        });
    }
    
    // ===== DASHBOARD FUNCTIONALITY =====
    if (document.querySelector('.dashboard-page')) {
        initializeDashboard();
    }
});

// ===== DASHBOARD INITIALIZATION =====
function initializeDashboard() {
    // Check if user is logged in
    const user = getUserData();
    if (!user) {
        window.location.href = 'index.html';
        return;
    }
    
    // Display username
    const usernameElements = document.querySelectorAll('#dashboardUsername, #profileUsername');
    usernameElements.forEach(el => {
        if (el) el.textContent = user.username;
    });
    
    // Display member since
    const memberSinceElement = document.getElementById('memberSince');
    if (memberSinceElement) {
        const joinDate = new Date(user.createdAt);
        memberSinceElement.textContent = joinDate.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
    
    // Display stats
    updateUserStats(user);
    
    // Initialize system time
    updateSystemTime();
    setInterval(updateSystemTime, 1000);
    
    // Initialize sidebar navigation
    initializeSidebar();
    
    // Initialize theme
    initializeTheme(user.theme);
    
    // Initialize tools
    initializeTools();
    
    // Initialize logout
    initializeLogout();
    
    // Initialize theme toggle
    initializeThemeToggle();
    
    // Initialize clear data button
    initializeClearData();
}

// ===== USER MANAGEMENT =====
function getUserData() {
    const userData = localStorage.getItem('xalpha_user');
    return userData ? JSON.parse(userData) : null;
}

function updateUserStats(user) {
    // Update stats on profile page
    document.getElementById('loginCount').textContent = user.loginCount || 1;
    document.getElementById('aiChatCount').textContent = user.aiChatCount || 0;
    document.getElementById('weatherChecks').textContent = user.weatherChecks || 0;
}

function updateUserStat(statName, increment = 1) {
    const user = getUserData();
    if (user) {
        user[statName] = (user[statName] || 0) + increment;
        localStorage.setItem('xalpha_user', JSON.stringify(user));
        updateUserStats(user);
    }
}

// ===== SIDEBAR NAVIGATION =====
function initializeSidebar() {
    const menuItems = document.querySelectorAll('.menu-item[data-section]');
    const sections = document.querySelectorAll('.content-section');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all
            menuItems.forEach(i => i.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            // Add active class to clicked item
            this.classList.add('active');
            
            // Show corresponding section
            const sectionId = this.getAttribute('data-section') + '-section';
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.add('active');
            }
            
            // Special handling for AI Assistant and Weather sections
            if (this.getAttribute('data-section') === 'ai-assistant') {
                // Load AI interface if not already loaded
                if (typeof initializeAIChat === 'function') {
                    setTimeout(initializeAIChat, 100);
                }
            } else if (this.getAttribute('data-section') === 'weather') {
                // Load weather if not already loaded
                if (typeof loadWeatherData === 'function') {
                    updateUserStat('weatherChecks');
                    setTimeout(loadWeatherData, 100);
                }
            }
        });
    });
    
    // Dashboard card buttons
    const cardButtons = document.querySelectorAll('.card-btn[data-section]');
    cardButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            const menuItem = document.querySelector(`.menu-item[data-section="${section}"]`);
            if (menuItem) menuItem.click();
        });
    });
}

// ===== THEME MANAGEMENT =====
function initializeTheme(themeName = 'cyberpunk') {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove('theme-cyberpunk', 'theme-matrix', 'theme-purple');
    
    // Add selected theme class
    root.classList.add(`theme-${themeName}`);
    
    // Set CSS variables based on theme
    switch(themeName) {
        case 'matrix':
            setThemeColors('#00ff41', '#009900', '#ff00ff');
            break;
        case 'purple':
            setThemeColors('#ff00ff', '#9900cc', '#00ff88');
            break;
        default: // cyberpunk
            setThemeColors('#00f3ff', '#0066ff', '#ff00ff');
    }
    
    // Update user theme preference
    const user = getUserData();
    if (user) {
        user.theme = themeName;
        localStorage.setItem('xalpha_user', JSON.stringify(user));
    }
}

function setThemeColors(primary, secondary, accent) {
    const root = document.documentElement;
    root.style.setProperty('--primary-color', primary);
    root.style.setProperty('--secondary-color', secondary);
    root.style.setProperty('--accent-color', accent);
}

function initializeThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const themeModal = document.getElementById('themeModal');
    const themeOptions = document.querySelectorAll('.theme-option');
    const modalClose = document.querySelector('.modal-close');
    const applyThemeBtn = document.getElementById('applyTheme');
    
    if (themeToggle && themeModal) {
        themeToggle.addEventListener('click', () => {
            themeModal.classList.add('active');
        });
        
        modalClose.addEventListener('click', () => {
            themeModal.classList.remove('active');
        });
        
        // Close modal when clicking outside
        themeModal.addEventListener('click', (e) => {
            if (e.target === themeModal) {
                themeModal.classList.remove('active');
            }
        });
        
        // Theme option selection
        let selectedTheme = 'cyberpunk';
        themeOptions.forEach(option => {
            option.addEventListener('click', () => {
                themeOptions.forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
                selectedTheme = option.getAttribute('data-theme');
            });
        });
        
        // Apply theme
        applyThemeBtn.addEventListener('click', () => {
            initializeTheme(selectedTheme);
            themeModal.classList.remove('active');
            showNotification(`Theme changed to ${selectedTheme}`, 'success');
        });
    }
    
    // Settings page theme options
    const settingsThemeOptions = document.querySelectorAll('.settings-group .theme-option');
    settingsThemeOptions.forEach(option => {
        option.addEventListener('click', () => {
            const theme = option.getAttribute('data-theme');
            initializeTheme(theme);
            showNotification(`Theme changed to ${theme}`, 'success');
        });
    });
}

// ===== TOOLS FUNCTIONALITY =====
function initializeTools() {
    const toolButtons = document.querySelectorAll('.tool-btn');
    const toolsOutput = document.getElementById('toolsOutput');
    
    toolButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const toolCard = this.closest('.tool-card');
            const tool = toolCard.getAttribute('data-tool');
            
            // Clear previous output
            if (toolsOutput) {
                toolsOutput.innerHTML = '';
            }
            
            switch(tool) {
                case 'eonet':
                    loadEONETEvents();
                    break;
                case 'neows':
                    loadAsteroidData();
                    break;
                case 'health':
                    openHealthTool();
                    break;
                case 'theme':
                    document.getElementById('themeModal').classList.add('active');
                    break;
            }
        });
    });
}

async function loadEONETEvents() {
    const toolsOutput = document.getElementById('toolsOutput');
    if (!toolsOutput) return;
    
    toolsOutput.innerHTML = `
        <div class="loading-tools">
            <i class="fas fa-satellite fa-spin"></i>
            <p>Loading NASA EONET natural events...</p>
        </div>
    `;
    
    try {
        // Using NASA EONET API for natural events[citation:6]
        const response = await fetch('https://eonet.gsfc.nasa.gov/api/v3/events?limit=10');
        const data = await response.json();
        
        let html = `
            <h3><i class="fas fa-globe-americas"></i> Recent Natural Events (EONET)</h3>
            <div class="events-list">
        `;
        
        if (data.events && data.events.length > 0) {
            data.events.forEach(event => {
                const date = new Date(event.geometry[0].date).toLocaleDateString();
                const category = event.categories[0].title;
                
                html += `
                    <div class="event-item">
                        <div class="event-category ${category.toLowerCase()}">
                            <i class="fas fa-${getEventIcon(category)}"></i>
                        </div>
                        <div class="event-details">
                            <h4>${event.title}</h4>
                            <p>${category} • ${date}</p>
                            ${event.closed ? '<span class="event-status closed">CLOSED</span>' : '<span class="event-status open">ACTIVE</span>'}
                        </div>
                    </div>
                `;
            });
        } else {
            html += `<p class="no-data">No recent natural events found.</p>`;
        }
        
        html += `</div>`;
        toolsOutput.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading EONET data:', error);
        toolsOutput.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Failed to load natural events data. Please try again later.</p>
            </div>
        `;
    }
}

async function loadAsteroidData() {
    const toolsOutput = document.getElementById('toolsOutput');
    if (!toolsOutput) return;
    
    toolsOutput.innerHTML = `
        <div class="loading-tools">
            <i class="fas fa-meteor fa-spin"></i>
            <p>Loading NASA NeoWs asteroid data...</p>
        </div>
    `;
    
    try {
        // Using NASA NeoWs API for asteroid data[citation:10]
        const today = new Date().toISOString().split('T')[0];
        const response = await fetch(`https://api.nasa.gov/neo/rest/v1/feed?start_date=${today}&end_date=${today}&api_key=${API_KEYS.nasa}`);
        const data = await response.json();
        
        let html = `
            <h3><i class="fas fa-meteor"></i> Near Earth Objects Today (${today})</h3>
            <div class="asteroids-list">
        `;
        
        if (data.near_earth_objects && data.near_earth_objects[today]) {
            const asteroids = data.near_earth_objects[today].slice(0, 5);
            
            asteroids.forEach(asteroid => {
                const name = asteroid.name;
                const diameter = asteroid.estimated_diameter.meters.estimated_diameter_max.toFixed(0);
                const hazardous = asteroid.is_potentially_hazardous_asteroid;
                const missDistance = (asteroid.close_approach_data[0].miss_distance.kilometers / 1000000).toFixed(2);
                
                html += `
                    <div class="asteroid-item ${hazardous ? 'hazardous' : 'safe'}">
                        <div class="asteroid-icon">
                            <i class="fas fa-meteor"></i>
                        </div>
                        <div class="asteroid-details">
                            <h4>${name.replace(/[()]/g, '')}</h4>
                            <p>Diameter: ~${diameter}m • Miss Distance: ${missDistance}M km</p>
                            <span class="asteroid-status ${hazardous ? 'hazardous' : 'safe'}">
                                ${hazardous ? 'HAZARDOUS' : 'SAFE'}
                            </span>
                        </div>
                    </div>
                `;
            });
        } else {
            html += `<p class="no-data">No asteroid data available for today.</p>`;
        }
        
        html += `</div>`;
        toolsOutput.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading asteroid data:', error);
        toolsOutput.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Failed to load asteroid data. Please try again later.</p>
            </div>
        `;
    }
}

function openHealthTool() {
    const toolsOutput = document.getElementById('toolsOutput');
    if (!toolsOutput) return;
    
    toolsOutput.innerHTML = `
        <h3><i class="fas fa-heartbeat"></i> Health Assistant</h3>
        <div class="health-tool">
            <div class="health-inputs">
                <div class="input-group">
                    <label><i class="fas fa-weight"></i> Weight (kg)</label>
                    <input type="number" id="healthWeight" placeholder="Enter weight">
                </div>
                <div class="input-group">
                    <label><i class="fas fa-ruler-vertical"></i> Height (cm)</label>
                    <input type="number" id="healthHeight" placeholder="Enter height">
                </div>
                <div class="input-group">
                    <label><i class="fas fa-heart"></i> Heart Rate (bpm)</label>
                    <input type="number" id="healthHeart" placeholder="Enter heart rate">
                </div>
                <button class="health-calculate-btn">
                    <i class="fas fa-calculator"></i> CALCULATE HEALTH METRICS
                </button>
            </div>
            <div class="health-results" id="healthResults"></div>
        </div>
    `;
    
    // Add event listener for calculate button
    setTimeout(() => {
        const calculateBtn = document.querySelector('.health-calculate-btn');
        if (calculateBtn) {
            calculateBtn.addEventListener('click', calculateHealthMetrics);
        }
    }, 100);
}

function calculateHealthMetrics() {
    const weight = parseFloat(document.getElementById('healthWeight').value);
    const height = parseFloat(document.getElementById('healthHeight').value);
    const heartRate = parseFloat(document.getElementById('healthHeart').value);
    
    const resultsDiv = document.getElementById('healthResults');
    
    if (!weight || !height || !heartRate) {
        resultsDiv.innerHTML = `<p class="error">Please fill in all fields</p>`;
        return;
    }
    
    // Calculate BMI
    const heightM = height / 100;
    const bmi = (weight / (heightM * heightM)).toFixed(1);
    
    // Determine BMI category
    let bmiCategory = '';
    if (bmi < 18.5) bmiCategory = 'Underweight';
    else if (bmi < 25) bmiCategory = 'Normal weight';
    else if (bmi < 30) bmiCategory = 'Overweight';
    else bmiCategory = 'Obese';
    
    // Determine heart rate status
    let heartStatus = '';
    if (heartRate < 60) heartStatus = 'Low (bradycardia)';
    else if (heartRate <= 100) heartStatus = 'Normal';
    else heartStatus = 'High (tachycardia)';
    
    resultsDiv.innerHTML = `
        <h4>Health Results:</h4>
        <div class="result-item">
            <strong>BMI:</strong> ${bmi} (${bmiCategory})
            <div class="bmi-bar">
                <div class="bmi-fill" style="width: ${Math.min((bmi / 40) * 100, 100)}%"></div>
            </div>
        </div>
        <div class="result-item">
            <strong>Heart Rate:</strong> ${heartRate} bpm (${heartStatus})
        </div>
        <div class="result-item">
            <strong>Recommendations:</strong>
            <ul>
                <li>${getHealthRecommendation(bmiCategory, heartStatus)}</li>
                <li>Consult with a healthcare professional for personalized advice</li>
            </ul>
        </div>
    `;
}

function getHealthRecommendation(bmiCategory, heartStatus) {
    if (bmiCategory === 'Normal weight' && heartStatus === 'Normal') {
        return 'Maintain your healthy lifestyle with regular exercise and balanced diet.';
    } else if (bmiCategory === 'Overweight' || bmiCategory === 'Obese') {
        return 'Consider increasing physical activity and consulting a nutritionist.';
    } else if (heartStatus.includes('High') || heartStatus.includes('Low')) {
        return 'Monitor your heart rate and consider consulting a cardiologist.';
    }
    return 'Maintain regular health check-ups and a balanced lifestyle.';
}

function getEventIcon(category) {
    const icons = {
        'Severe Storms': 'bolt',
        'Wildfires': 'fire',
        'Volcanoes': 'mountain',
        'Earthquakes': 'globe-americas',
        'Floods': 'water',
        'Landslides': 'mountain',
        'Extreme Temperatures': 'thermometer-half',
        'Drought': 'sun'
    };
    return icons[category] || 'exclamation-triangle';
}

// ===== SYSTEM FUNCTIONS =====
function updateSystemTime() {
    const timeElement = document.getElementById('systemTime');
    if (timeElement) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        timeElement.textContent = timeString;
    }
}

function initializeLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Clear user session data (keep user data for next login)
            // localStorage.removeItem('xalpha_user'); // Uncomment to clear on logout
            
            // Redirect to login page
            window.location.href = 'index.html';
        });
    }
}

function initializeClearData() {
    const clearDataBtn = document.getElementById('clearDataBtn');
    if (clearDataBtn) {
        clearDataBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to clear all local data? This will log you out and remove all saved preferences.')) {
                localStorage.clear();
                showNotification('All local data cleared. Redirecting to login...', 'info');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
            }
        });
    }
}

// ===== UI UTILITY FUNCTIONS =====
function showLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.classList.add('active');
    }
}

function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.classList.remove('active');
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${getNotificationIcon(type)}"></i>
        <span>${message}</span>
        <button class="notification-close">&times;</button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Add styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 30px;
                right: 30px;
                padding: 15px 20px;
                border-radius: 10px;
                background: rgba(16, 18, 36, 0.95);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(0, 243, 255, 0.3);
                display: flex;
                align-items: center;
                gap: 15px;
                z-index: 9999;
                transform: translateX(150%);
                transition: transform 0.3s ease;
                max-width: 400px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            }
            .notification.show {
                transform: translateX(0);
            }
            .notification i {
                font-size: 20px;
            }
            .notification-success { border-color: rgba(0, 255, 136, 0.5); }
            .notification-success i { color: #00ff88; }
            .notification-error { border-color: rgba(255, 51, 102, 0.5); }
            .notification-error i { color: #ff3366; }
            .notification-info { border-color: rgba(0, 243, 255, 0.5); }
            .notification-info i { color: #00f3ff; }
            .notification-close {
                background: none;
                border: none;
                color: inherit;
                font-size: 24px;
                cursor: pointer;
                margin-left: auto;
                padding: 0;
                line-height: 1;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Show notification
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Close button
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    switch(type) {
        case 'success': return 'check-circle';
        case 'error': return 'exclamation-circle';
        default: return 'info-circle';
    }
}

// Add some CSS for the tools
document.addEventListener('DOMContentLoaded', function() {
    // Add tool-specific styles
    const toolStyles = `
        .loading-tools {
            text-align: center;
            padding: 40px;
        }
        .loading-tools i {
            font-size: 48px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }
        .events-list, .asteroids-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 20px;
        }
        .event-item, .asteroid-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            border-left: 4px solid var(--primary-color);
        }
        .event-category, .asteroid-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            background: rgba(0, 243, 255, 0.1);
            color: var(--primary-color);
        }
        .event-details, .asteroid-details {
            flex: 1;
        }
        .event-details h4, .asteroid-details h4 {
            margin-bottom: 5px;
            font-size: 16px;
        }
        .event-details p, .asteroid-details p {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }
        .event-status, .asteroid-status {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        .event-status.open, .asteroid-status.safe {
            background: rgba(0, 255, 136, 0.1);
            color: var(--success-color);
            border: 1px solid rgba(0, 255, 136, 0.3);
        }
        .event-status.closed, .asteroid-status.hazardous {
            background: rgba(255, 51, 102, 0.1);
            color: var(--danger-color);
            border: 1px solid rgba(255, 51, 102, 0.3);
        }
        .error-message {
            text-align: center;
            padding: 40px;
            color: var(--danger-color);
        }
        .error-message i {
            font-size: 48px;
            margin-bottom: 20px;
        }
        .no-data {
            text-align: center;
            padding: 30px;
            color: var(--text-secondary);
        }
        .health-tool {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        .health-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .health-inputs .input-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .health-inputs label {
            font-weight: 600;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .health-inputs input {
            padding: 12px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(0, 243, 255, 0.3);
            border-radius: 8px;
            color: var(--text-color);
            font-family: 'Exo 2', sans-serif;
        }
        .health-calculate-btn {
            grid-column: 1 / -1;
            padding: 15px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 8px;
            color: var(--dark-bg);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .health-calculate-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 243, 255, 0.3);
        }
        .health-results {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 25px;
        }
        .result-item {
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .result-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        .bmi-bar {
            width: 100%;
            height: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            margin-top: 10px;
            overflow: hidden;
        }
        .bmi-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 5px;
            transition: width 1s ease;
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = toolStyles;
    document.head.appendChild(styleSheet);
});