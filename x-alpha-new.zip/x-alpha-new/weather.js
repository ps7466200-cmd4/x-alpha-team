// X-ALPHA Weather System for Biratnagar, Nepal
class XAlphaWeather {
    constructor() {
        this.apiKey = '8f376d0650b74e158fc175823251012';
        this.location = 'Biratnagar';
        this.country = 'Nepal';
        this.currentWeather = null;
        this.forecast = [];
        
        // Initialize when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            if (document.getElementById('weather-section')) {
                this.initializeWeather();
            }
        });
    }
    
    initializeWeather() {
        const weatherContainer = document.getElementById('weatherContainer');
        if (!weatherContainer) return;
        
        // Create weather interface
        weatherContainer.innerHTML = `
            <div class="weather-dashboard">
                <div class="weather-header">
                    <h3><i class="fas fa-map-marker-alt"></i> ${this.location}, ${this.country}</h3>
                    <div class="weather-actions">
                        <button id="refreshWeather">
                            <i class="fas fa-sync-alt"></i> REFRESH
                        </button>
                        <div class="last-updated" id="lastUpdated">Updating...</div>
                    </div>
                </div>
                
                <div class="weather-main" id="weatherMain">
                    <!-- Current weather will be loaded here -->
                    <div class="weather-loading">
                        <i class="fas fa-cloud-sun fa-spin"></i>
                        <p>Loading weather data for ${this.location}...</p>
                    </div>
                </div>
                
                <div class="weather-details" id="weatherDetails">
                    <!-- Weather details will be loaded here -->
                </div>
                
                <div class="weather-forecast" id="weatherForecast">
                    <!-- Forecast will be loaded here -->
                </div>
                
                <div class="weather-animation">
                    <div class="particles-container" id="weatherParticles">
                        <!-- Weather particles/animation -->
                    </div>
                </div>
                
                <div class="weather-footer">
                    <p>
                        <i class="fas fa-info-circle"></i>
                        Data provided by WeatherAPI.com. Location: ${this.location}, Nepal[citation:3].
                    </p>
                </div>
            </div>
        `;
        
        // Add event listeners
        this.attachEventListeners();
        
        // Load initial weather data
        this.loadWeatherData();
    }
    
    attachEventListeners() {
        const refreshBtn = document.getElementById('refreshWeather');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadWeatherData());
        }
    }
    
    async loadWeatherData() {
        // Show loading state
        this.showLoading();
        
        try {
            // Using WeatherAPI.com for Biratnagar, Nepal[citation:3]
            const response = await fetch(`https://api.weatherapi.com/v1/current.json?key=${this.apiKey}&q=${this.location}&aqi=no`);
            const data = await response.json();
            
            if (data && data.current) {
                this.currentWeather = data;
                
                // Update UI with weather data
                this.updateWeatherUI();
                
                // Update last updated time
                this.updateLastUpdated();
                
                // Update user stats
                this.updateUserStats();
                
                // Create weather animation based on condition
                this.createWeatherAnimation(data.current.condition.text);
                
                // Show success notification
                showNotification(`Weather data updated for ${this.location}`, 'success');
            } else {
                throw new Error('Invalid weather data');
            }
            
        } catch (error) {
            console.error('Weather API Error:', error);
            
            // Show error in UI
            const weatherMain = document.getElementById('weatherMain');
            if (weatherMain) {
                weatherMain.innerHTML = `
                    <div class="weather-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>Weather Data Unavailable</h3>
                        <p>Unable to fetch weather data for ${this.location}. Please check your connection or try again later.</p>
                        <button id="retryWeather" class="retry-btn">
                            <i class="fas fa-redo"></i> RETRY
                        </button>
                    </div>
                `;
                
                // Add retry event listener
                const retryBtn = document.getElementById('retryWeather');
                if (retryBtn) {
                    retryBtn.addEventListener('click', () => this.loadWeatherData());
                }
            }
            
            showNotification('Failed to load weather data', 'error');
        }
    }
    
    updateWeatherUI() {
        if (!this.currentWeather) return;
        
        const weather = this.currentWeather.current;
        const location = this.currentWeather.location;
        
        // Update main weather display
        const weatherMain = document.getElementById('weatherMain');
        if (weatherMain) {
            weatherMain.innerHTML = `
                <div class="current-weather">
                    <div class="weather-icon">
                        <i class="${this.getWeatherIcon(weather.condition.text)}"></i>
                        <div class="icon-glow"></div>
                    </div>
                    <div class="weather-temp">
                        <div class="temp-value">${Math.round(weather.temp_c)}°C</div>
                        <div class="temp-feels">Feels like ${Math.round(weather.feelslike_c)}°C</div>
                        <div class="temp-desc">${weather.condition.text}</div>
                    </div>
                    <div class="weather-location">
                        <h3>${location.name}, ${location.country}</h3>
                        <p>${location.localtime}</p>
                    </div>
                </div>
            `;
        }
        
        // Update weather details
        const weatherDetails = document.getElementById('weatherDetails');
        if (weatherDetails) {
            weatherDetails.innerHTML = `
                <h4><i class="fas fa-chart-bar"></i> WEATHER DETAILS</h4>
                <div class="details-grid">
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-tint"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">Humidity</div>
                            <div class="detail-value">${weather.humidity}%</div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-wind"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">Wind</div>
                            <div class="detail-value">${weather.wind_kph} km/h</div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-compress-alt"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">Pressure</div>
                            <div class="detail-value">${weather.pressure_mb} mb</div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">Visibility</div>
                            <div class="detail-value">${weather.vis_km} km</div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-cloud"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">Cloud Cover</div>
                            <div class="detail-value">${weather.cloud}%</div>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-icon">
                            <i class="fas fa-thermometer-half"></i>
                        </div>
                        <div class="detail-info">
                            <div class="detail-label">UV Index</div>
                            <div class="detail-value">${weather.uv}</div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Update forecast (using static data for now, in real app would fetch forecast)
        this.updateForecast();
    }
    
    updateForecast() {
        const weatherForecast = document.getElementById('weatherForecast');
        if (!weatherForecast) return;
        
        // Static forecast data for Biratnagar[citation:3]
        const forecastData = [
            { day: 'Today', high: 25, low: 16, condition: 'Sunny', icon: 'fa-sun' },
            { day: 'Tomorrow', high: 26, low: 16, condition: 'Sunny', icon: 'fa-sun' },
            { day: 'Sat', high: 26, low: 16, condition: 'Partly Cloudy', icon: 'fa-cloud-sun' },
            { day: 'Sun', high: 26, low: 16, condition: 'Clear', icon: 'fa-sun' },
            { day: 'Mon', high: 26, low: 16, condition: 'Clear', icon: 'fa-sun' }
        ];
        
        let forecastHTML = `
            <h4><i class="fas fa-calendar-alt"></i> 5-DAY FORECAST</h4>
            <div class="forecast-cards">
        `;
        
        forecastData.forEach(day => {
            forecastHTML += `
                <div class="forecast-card">
                    <div class="forecast-day">${day.day}</div>
                    <div class="forecast-icon">
                        <i class="fas ${day.icon}"></i>
                    </div>
                    <div class="forecast-temp">
                        <span class="temp-high">${day.high}°</span>
                        <span class="temp-low">${day.low}°</span>
                    </div>
                    <div class="forecast-condition">${day.condition}</div>
                </div>
            `;
        });
        
        forecastHTML += `</div>`;
        weatherForecast.innerHTML = forecastHTML;
    }
    
    getWeatherIcon(condition) {
        const conditionLower = condition.toLowerCase();
        
        if (conditionLower.includes('sunny') || conditionLower.includes('clear')) {
            return 'fas fa-sun';
        } else if (conditionLower.includes('partly cloudy')) {
            return 'fas fa-cloud-sun';
        } else if (conditionLower.includes('cloudy') || conditionLower.includes('overcast')) {
            return 'fas fa-cloud';
        } else if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
            return 'fas fa-cloud-rain';
        } else if (conditionLower.includes('storm') || conditionLower.includes('thunder')) {
            return 'fas fa-bolt';
        } else if (conditionLower.includes('snow') || conditionLower.includes('ice')) {
            return 'fas fa-snowflake';
        } else if (conditionLower.includes('fog') || conditionLower.includes('mist')) {
            return 'fas fa-smog';
        } else {
            return 'fas fa-cloud';
        }
    }
    
    createWeatherAnimation(condition) {
        const particlesContainer = document.getElementById('weatherParticles');
        if (!particlesContainer) return;
        
        particlesContainer.innerHTML = '';
        
        const conditionLower = condition.toLowerCase();
        let particleCount = 20;
        let particleType = 'circle';
        let particleColor = 'var(--primary-color)';
        
        if (conditionLower.includes('rain')) {
            particleCount = 50;
            particleType = 'line';
            particleColor = '#00f3ff';
            this.createRainAnimation(particlesContainer);
        } else if (conditionLower.includes('cloud')) {
            particleCount = 30;
            this.createCloudAnimation(particlesContainer);
        } else if (conditionLower.includes('sun')) {
            particleCount = 15;
            this.createSunAnimation(particlesContainer);
        } else if (conditionLower.includes('snow')) {
            particleCount = 100;
            this.createSnowAnimation(particlesContainer);
        } else {
            // Default floating particles
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'weather-particle';
                particle.style.cssText = `
                    position: absolute;
                    width: ${Math.random() * 6 + 2}px;
                    height: ${Math.random() * 6 + 2}px;
                    background: ${particleColor};
                    border-radius: 50%;
                    opacity: ${Math.random() * 0.5 + 0.2};
                    top: ${Math.random() * 100}%;
                    left: ${Math.random() * 100}%;
                    box-shadow: 0 0 10px ${particleColor};
                    animation: floatParticle ${Math.random() * 20 + 10}s infinite linear;
                `;
                particlesContainer.appendChild(particle);
            }
        }
    }
    
    createRainAnimation(container) {
        for (let i = 0; i < 30; i++) {
            const drop = document.createElement('div');
            drop.className = 'rain-drop';
            drop.style.cssText = `
                position: absolute;
                width: 2px;
                height: ${Math.random() * 20 + 10}px;
                background: linear-gradient(to bottom, transparent, #00f3ff);
                top: -20px;
                left: ${Math.random() * 100}%;
                animation: rainFall ${Math.random() * 1 + 0.5}s infinite linear;
                animation-delay: ${Math.random() * 2}s;
            `;
            container.appendChild(drop);
        }
        
        // Add rain animation CSS
        if (!document.querySelector('#rain-animation')) {
            const style = document.createElement('style');
            style.id = 'rain-animation';
            style.textContent = `
                @keyframes rainFall {
                    0% { transform: translateY(0) translateX(0); opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { transform: translateY(100px) translateX(10px); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    createCloudAnimation(container) {
        for (let i = 0; i < 5; i++) {
            const cloud = document.createElement('div');
            cloud.className = 'weather-cloud';
            cloud.style.cssText = `
                position: absolute;
                width: ${Math.random() * 60 + 40}px;
                height: ${Math.random() * 30 + 20}px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 50%;
                top: ${Math.random() * 80 + 10}%;
                left: ${Math.random() * 100}%;
                filter: blur(10px);
                animation: cloudFloat ${Math.random() * 40 + 20}s infinite linear;
            `;
            container.appendChild(cloud);
        }
    }
    
    createSunAnimation(container) {
        const sun = document.createElement('div');
        sun.className = 'weather-sun';
        sun.style.cssText = `
            position: absolute;
            width: 60px;
            height: 60px;
            background: radial-gradient(circle, #ffaa00, #ff6600);
            border-radius: 50%;
            top: 20%;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 0 50px #ffaa00;
            animation: sunPulse 3s infinite ease-in-out;
        `;
        container.appendChild(sun);
        
        // Add sun rays
        for (let i = 0; i < 12; i++) {
            const ray = document.createElement('div');
            ray.className = 'sun-ray';
            ray.style.cssText = `
                position: absolute;
                width: 4px;
                height: 30px;
                background: linear-gradient(to top, transparent, #ffaa00);
                top: 50%;
                left: 50%;
                transform-origin: bottom center;
                transform: translate(-50%, -50%) rotate(${i * 30}deg) translateY(-40px);
                border-radius: 2px;
                animation: rayPulse 3s infinite ease-in-out;
                animation-delay: ${i * 0.1}s;
            `;
            container.appendChild(ray);
        }
    }
    
    createSnowAnimation(container) {
        for (let i = 0; i < 50; i++) {
            const flake = document.createElement('div');
            flake.className = 'snow-flake';
            flake.style.cssText = `
                position: absolute;
                width: ${Math.random() * 8 + 4}px;
                height: ${Math.random() * 8 + 4}px;
                background: white;
                border-radius: 50%;
                top: -10px;
                left: ${Math.random() * 100}%;
                filter: blur(1px);
                opacity: ${Math.random() * 0.7 + 0.3};
                animation: snowFall ${Math.random() * 10 + 5}s infinite linear;
                animation-delay: ${Math.random() * 5}s;
            `;
            container.appendChild(flake);
        }
    }
    
    showLoading() {
        const weatherMain = document.getElementById('weatherMain');
        if (weatherMain) {
            weatherMain.innerHTML = `
                <div class="weather-loading">
                    <i class="fas fa-cloud-sun fa-spin"></i>
                    <p>Loading weather data for ${this.location}...</p>
                </div>
            `;
        }
        
        // Clear other sections
        const details = document.getElementById('weatherDetails');
        const forecast = document.getElementById('weatherForecast');
        if (details) details.innerHTML = '';
        if (forecast) forecast.innerHTML = '';
    }
    
    updateLastUpdated() {
        const lastUpdated = document.getElementById('lastUpdated');
        if (lastUpdated) {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            lastUpdated.textContent = `Updated: ${timeString}`;
        }
    }
    
    updateUserStats() {
        // Update weather check count in user stats
        const user = getUserData();
        if (user) {
            user.weatherChecks = (user.weatherChecks || 0) + 1;
            localStorage.setItem('xalpha_user', JSON.stringify(user));
            
            // Update UI if on profile page
            const weatherChecksElement = document.getElementById('weatherChecks');
            if (weatherChecksElement) {
                weatherChecksElement.textContent = user.weatherChecks;
            }
        }
    }
}

// Initialize weather system when script loads
const xalphaWeather = new XAlphaWeather();

// Helper function to get user data (from script.js)
function getUserData() {
    const userData = localStorage.getItem('xalpha_user');
    return userData ? JSON.parse(userData) : null;
}

// Helper function for notifications (from script.js)
function showNotification(message, type = 'info') {
    // Implementation from script.js
}

// Export for use in dashboard
function loadWeatherData() {
    xalphaWeather.loadWeatherData();
}

// Add weather-specific CSS
document.addEventListener('DOMContentLoaded', function() {
    const weatherStyles = `
        .weather-dashboard {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }
        
        .weather-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(0, 243, 255, 0.2);
        }
        
        .weather-header h3 {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .weather-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        #refreshWeather {
            padding: 10px 20px;
            background: rgba(0, 243, 255, 0.1);
            border: 1px solid var(--primary-color);
            border-radius: 8px;
            color: var(--primary-color);
            font-family: 'Exo 2', sans-serif;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        
        #refreshWeather:hover {
            background: rgba(0, 243, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 243, 255, 0.2);
        }
        
        #refreshWeather i {
            transition: transform 0.3s ease;
        }
        
        #refreshWeather:hover i {
            transform: rotate(180deg);
        }
        
        .last-updated {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .weather-main {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .current-weather {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 30px;
            position: relative;
            z-index: 2;
        }
        
        .weather-icon {
            position: relative;
            font-size: 80px;
            color: var(--primary-color);
        }
        
        .icon-glow {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 120px;
            height: 120px;
            background: radial-gradient(circle, var(--primary-color), transparent 70%);
            opacity: 0.3;
            filter: blur(20px);
            z-index: -1;
        }
        
        .weather-temp {
            flex: 1;
            text-align: center;
        }
        
        .temp-value {
            font-family: 'Orbitron', sans-serif;
            font-size: 64px;
            font-weight: 700;
            color: var(--primary-color);
            line-height: 1;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(0, 243, 255, 0.5);
        }
        
        .temp-feels {
            font-size: 18px;
            color: var(--text-secondary);
            margin-bottom: 5px;
        }
        
        .temp-desc {
            font-size: 24px;
            font-weight: 600;
            color: var(--text-color);
        }
        
        .weather-location {
            text-align: right;
        }
        
        .weather-location h3 {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            margin-bottom: 10px;
            color: var(--primary-color);
        }
        
        .weather-location p {
            color: var(--text-secondary);
            font-size: 16px;
        }
        
        .weather-details {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            padding: 25px;
        }
        
        .weather-details h4 {
            font-family: 'Orbitron', sans-serif;
            font-size: 18px;
            margin-bottom: 25px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .detail-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 243, 255, 0.1);
            border-left-color: var(--accent-color);
        }
        
        .detail-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: rgba(0, 243, 255, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: var(--primary-color);
        }
        
        .detail-info {
            flex: 1;
        }
        
        .detail-label {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            font-weight: 700;
            color: var(--text-color);
        }
        
        .weather-forecast {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            padding: 25px;
        }
        
        .weather-forecast h4 {
            font-family: 'Orbitron', sans-serif;
            font-size: 18px;
            margin-bottom: 25px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .forecast-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .forecast-card {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 243, 255, 0.1);
        }
        
        .forecast-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-color);
            box-shadow: 0 10px 20px rgba(0, 243, 255, 0.1);
        }
        
        .forecast-day {
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text-color);
        }
        
        .forecast-icon {
            font-size: 36px;
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .forecast-temp {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .temp-high {
            font-weight: 700;
            color: var(--text-color);
        }
        
        .temp-low {
            color: var(--text-secondary);
        }
        
        .forecast-condition {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .weather-animation {
            height: 200px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        
        .particles-container {
            width: 100%;
            height: 100%;
            position: relative;
        }
        
        .weather-footer {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(0, 243, 255, 0.2);
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .weather-footer i {
            color: var(--primary-color);
            margin-right: 10px;
        }
        
        .weather-loading, .weather-error {
            text-align: center;
            padding: 60px 30px;
        }
        
        .weather-loading i {
            font-size: 64px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }
        
        .weather-error i {
            font-size: 64px;
            color: var(--danger-color);
            margin-bottom: 20px;
        }
        
        .weather-error h3 {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            margin-bottom: 15px;
            color: var(--danger-color);
        }
        
        .weather-error p {
            margin-bottom: 25px;
            color: var(--text-secondary);
        }
        
        .retry-btn {
            padding: 12px 25px;
            background: rgba(0, 243, 255, 0.1);
            border: 1px solid var(--primary-color);
            border-radius: 8px;
            color: var(--primary-color);
            font-family: 'Exo 2', sans-serif;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        
        .retry-btn:hover {
            background: rgba(0, 243, 255, 0.2);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 243, 255, 0.2);
        }
        
        /* Animation keyframes for weather */
        @keyframes floatParticle {
            0% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-50px) translateX(20px); }
            50% { transform: translateY(-20px) translateX(40px); }
            75% { transform: translateY(-60px) translateX(10px); }
            100% { transform: translateY(0) translateX(0); }
        }
        
        @keyframes cloudFloat {
            0% { transform: translateX(-100px) translateY(0); opacity: 0; }
            10% { opacity: 0.5; }
            90% { opacity: 0.5; }
            100% { transform: translateX(calc(100vw + 100px)) translateY(20px); opacity: 0; }
        }
        
        @keyframes sunPulse {
            0%, 100% { transform: translateX(-50%) scale(1); box-shadow: 0 0 50px #ffaa00; }
            50% { transform: translateX(-50%) scale(1.1); box-shadow: 0 0 80px #ffaa00; }
        }
        
        @keyframes rayPulse {
            0%, 100% { opacity: 0.3; transform: translate(-50%, -50%) rotate(var(--rotation)) translateY(-40px) scale(1); }
            50% { opacity: 1; transform: translate(-50%, -50%) rotate(var(--rotation)) translateY(-40px) scale(1.2); }
        }
        
        @keyframes snowFall {
            0% { transform: translateY(0) translateX(0); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(210px) translateX(20px); opacity: 0; }
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .weather-header {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
            
            .current-weather {
                flex-direction: column;
                text-align: center;
            }
            
            .weather-location {
                text-align: center;
            }
            
            .temp-value {
                font-size: 48px;
            }
            
            .forecast-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 480px) {
            .forecast-cards {
                grid-template-columns: 1fr;
            }
            
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = weatherStyles;
    document.head.appendChild(styleSheet);
});